
import { Message, Usage, Store } from '../models/index.js';
import * as whatsapp from './whatsappService.js';

export const sendMessageWithBilling = async (store, from, body, type, sendCallback) => {
    try {
        // Check balance
        if (store.wallet_balance < (store.message_cost || 0.50) && store.wallet_balance !== null) {
            console.warn(`⚠️ Store ${store.name} has low balance: ${store.wallet_balance}`);
        }

        const response = await sendCallback();
        const messageId = response?.messages?.[0]?.id;

        // Log outgoing message
        await Message.create({
            store_id: store.id,
            customer_phone: from,
            direction: 'out',
            body: body,
            type: type,
            message_id: messageId
        });

        // Deduct from wallet
        const cost = store.message_cost || 0.50;
        await Store.updateWallet(store.id, -cost);

        // Log usage
        await Usage.log({
            store_id: store.id,
            type: 'outgoing_msg',
            cost: cost,
            balance_after: store.wallet_balance - cost,
            details: `Notification to ${from} (${type})`
        });

        return response;
    } catch (error) {
        console.error('Error in sendMessageWithBilling service:', error);
        throw error;
    }
};
